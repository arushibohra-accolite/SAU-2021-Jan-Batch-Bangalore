export class Session_Model{
    name: String;
    trainer: String;
    date?: Date;
}