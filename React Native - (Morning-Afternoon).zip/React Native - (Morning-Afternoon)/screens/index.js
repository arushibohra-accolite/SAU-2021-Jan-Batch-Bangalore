import Login from "./login/index";
import ViewNotes from "./notes/showNotes";
import AddNotes from "./notes/addNewNotes";
export { Login, ViewNotes, AddNotes };