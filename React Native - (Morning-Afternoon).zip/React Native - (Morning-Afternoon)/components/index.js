import NoteCard from "./IndividualCard";
import NewNoteCard from "./FreshNote";
export { NoteCard, NewNoteCard };